/*
  # Schema Update for Study App

  1. Tables
    - `profiles`: User profile information
    - `tasks`: Study tasks with progress tracking
    - `friendships`: User connections and friend requests
  
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Safe policy creation with existence checks
*/

-- Create profiles table if it doesn't exist
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text NOT NULL,
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create tasks table if it doesn't exist
CREATE TABLE IF NOT EXISTS tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text,
  due_date date NOT NULL,
  progress integer DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create friendships table if it doesn't exist
CREATE TABLE IF NOT EXISTS friendships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  friend_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  status text CHECK (status IN ('pending', 'accepted')) DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, friend_id)
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE friendships ENABLE ROW LEVEL SECURITY;

-- Safe policy creation functions
DO $$
BEGIN
    -- Profiles policies
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'profiles' 
        AND policyname = 'Users can view their own profile'
    ) THEN
        CREATE POLICY "Users can view their own profile"
            ON profiles FOR SELECT
            TO authenticated
            USING (auth.uid() = id);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'profiles' 
        AND policyname = 'Users can update their own profile'
    ) THEN
        CREATE POLICY "Users can update their own profile"
            ON profiles FOR UPDATE
            TO authenticated
            USING (auth.uid() = id);
    END IF;

    -- Tasks policies
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'tasks' 
        AND policyname = 'Users can view their own tasks'
    ) THEN
        CREATE POLICY "Users can view their own tasks"
            ON tasks FOR SELECT
            TO authenticated
            USING (auth.uid() = user_id);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'tasks' 
        AND policyname = 'Users can view their friends tasks'
    ) THEN
        CREATE POLICY "Users can view their friends tasks"
            ON tasks FOR SELECT
            TO authenticated
            USING (
                EXISTS (
                    SELECT 1 FROM friendships
                    WHERE (friendships.user_id = auth.uid() AND friendships.friend_id = tasks.user_id
                        OR friendships.friend_id = auth.uid() AND friendships.user_id = tasks.user_id)
                    AND friendships.status = 'accepted'
                )
            );
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'tasks' 
        AND policyname = 'Users can create their own tasks'
    ) THEN
        CREATE POLICY "Users can create their own tasks"
            ON tasks FOR INSERT
            TO authenticated
            WITH CHECK (auth.uid() = user_id);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'tasks' 
        AND policyname = 'Users can update their own tasks'
    ) THEN
        CREATE POLICY "Users can update their own tasks"
            ON tasks FOR UPDATE
            TO authenticated
            USING (auth.uid() = user_id);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'tasks' 
        AND policyname = 'Users can delete their own tasks'
    ) THEN
        CREATE POLICY "Users can delete their own tasks"
            ON tasks FOR DELETE
            TO authenticated
            USING (auth.uid() = user_id);
    END IF;

    -- Friendships policies
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'friendships' 
        AND policyname = 'Users can view their friendships'
    ) THEN
        CREATE POLICY "Users can view their friendships"
            ON friendships FOR SELECT
            TO authenticated
            USING (auth.uid() = user_id OR auth.uid() = friend_id);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'friendships' 
        AND policyname = 'Users can create friendship requests'
    ) THEN
        CREATE POLICY "Users can create friendship requests"
            ON friendships FOR INSERT
            TO authenticated
            WITH CHECK (auth.uid() = user_id);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'friendships' 
        AND policyname = 'Users can update their friendship status'
    ) THEN
        CREATE POLICY "Users can update their friendship status"
            ON friendships FOR UPDATE
            TO authenticated
            USING (auth.uid() = friend_id AND status = 'pending');
    END IF;
END
$$;